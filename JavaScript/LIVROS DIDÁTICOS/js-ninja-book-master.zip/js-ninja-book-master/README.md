# JS Ninja Book

Como aprender JavaScript do Zero ao Ninja.

## Sobre este livro

Sim! Eu sei o que você está pensando! Mais um livro de JavaScript...

Pois é... A vida de um dev JS não seria completa se:

1. Não criasse mais um framework para ver no que dá
2. Escrever um livro
3. Ter um filho (filhos peludos ou com penas contam)

Sendo assim o #1823466234 livro de JavaScript no mercado serve para te ajudar, já que você terá o exato  conteúdo que meus alunos (que pagaram pelo curso) tiveram.

Além de me ajudar a concluír o item 2 da lista ;)

## Sobre o autor

Me chamo Felipe Fontoura e sou autor do projeto Dev Samurai (https://devsamurai.com.br) e tenho um canal no YouTube (Canal Dev Samurai).

Eu amo programar e estou fazendo isso a pouco mais de 20 anos e nos últimos 5 anos larguei tudo para viver apenas do que eu mais amo **programar** e **ensinar programação**.

## Contribuições

Caso você goste (ou não) desse livro me envie uma mensagem no Instagram @devsamurai, ficarei feliz em ler e discutir contigo.

Caso encontre algum erro ou gostaria de contribuir abra uma issue no repostório do livro https://github.com/felipefontoura/techbook/issues
